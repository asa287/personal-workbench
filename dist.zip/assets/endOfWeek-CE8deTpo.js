import{c as D}from"./index-BMSPPxcF.js";import{D as o,F as l,G as g}from"./date-BczuxZlA.js";/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const M=D("ChevronLeft",[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]]);/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const m=D("ChevronRight",[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]]);function k(s,t){const e=o(s);if(isNaN(t))return l(s,NaN);if(!t)return e;const a=e.getDate(),n=l(s,e.getTime());n.setMonth(e.getMonth()+t+1,0);const c=n.getDate();return a>=c?n:(e.setFullYear(n.getFullYear(),n.getMonth(),a),e)}function w(s){const t=o(s),e=t.getMonth();return t.setFullYear(t.getFullYear(),e+1,0),t.setHours(23,59,59,999),t}function y(s,t){const e=o(s.start),a=o(s.end);let n=+e>+a;const c=n?+e:+a,r=n?a:e;r.setHours(0,0,0,0);let h=1;const u=[];for(;+r<=c;)u.push(o(r)),r.setDate(r.getDate()+h),r.setHours(0,0,0,0);return n?u.reverse():u}function v(s){const t=o(s);return t.setDate(1),t.setHours(0,0,0,0),t}function F(s,t){var h,u,f,d;const e=g(),a=(t==null?void 0:t.weekStartsOn)??((u=(h=t==null?void 0:t.locale)==null?void 0:h.options)==null?void 0:u.weekStartsOn)??e.weekStartsOn??((d=(f=e.locale)==null?void 0:f.options)==null?void 0:d.weekStartsOn)??0,n=o(s),c=n.getDay(),r=(c<a?-7:0)+6-(c-a);return n.setDate(n.getDate()+r),n.setHours(23,59,59,999),n}export{M as C,k as a,w as b,y as c,m as d,F as e,v as s};
