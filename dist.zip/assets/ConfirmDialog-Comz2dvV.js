import{c as x,j as e,B as r}from"./index-BMSPPxcF.js";import{M as l}from"./Input-DvnE0Txp.js";/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const y=x("Trash2",[["path",{d:"M3 6h18",key:"d0wm0j"}],["path",{d:"M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6",key:"4alrt4"}],["path",{d:"M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2",key:"v07s0e"}],["line",{x1:"10",x2:"10",y1:"11",y2:"17",key:"1uufr5"}],["line",{x1:"14",x2:"14",y1:"11",y2:"17",key:"xtxkd"}]]);function p({open:a,title:t="确认操作",message:i,confirmText:n="确认",cancelText:o="取消",destructive:c=!1,onConfirm:d,onCancel:s}){return e.jsx(l,{open:a,onClose:s,title:t,size:"sm",footer:e.jsxs(e.Fragment,{children:[e.jsx(r,{variant:"ghost",size:"md",onClick:s,children:o}),e.jsx(r,{variant:c?"danger":"primary",size:"md",onClick:d,children:n})]}),children:e.jsx("p",{className:"text-sm text-secondary leading-relaxed",children:i})})}export{p as C,y as T};
