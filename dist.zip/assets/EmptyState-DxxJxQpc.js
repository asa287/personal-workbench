import{c,j as e,a as l}from"./index-BMSPPxcF.js";/**
 * @license lucide-react v0.408.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const d=c("Pencil",[["path",{d:"M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z",key:"1a8usu"}],["path",{d:"m15 5 4 4",key:"1mk7zo"}]]);function n({icon:t,title:r,description:s,action:a,className:m}){return e.jsxs("div",{className:l("flex flex-col items-center justify-center py-12 px-6 text-center",m),children:[t&&e.jsx("div",{className:"mb-3 w-12 h-12 rounded-full bg-elevated border border-default flex items-center justify-center text-muted",children:t}),e.jsx("h3",{className:"text-sm font-medium text-primary",children:r}),s&&e.jsx("p",{className:"text-xs text-tertiary mt-1 max-w-sm",children:s}),a&&e.jsx("div",{className:"mt-4",children:a})]})}export{n as E,d as P};
